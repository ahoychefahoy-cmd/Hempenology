document.addEventListener('DOMContentLoaded',()=>{
 const body=document.body, menu=document.querySelector('.side-menu'), open=document.querySelector('[data-menu-open]');
 const closeEls=document.querySelectorAll('[data-menu-close]');
 const close=()=>{body.classList.remove('menu-open');if(menu)menu.setAttribute('aria-hidden','true');if(open)open.setAttribute('aria-expanded','false')};
 if(open)open.addEventListener('click',()=>{body.classList.add('menu-open');if(menu)menu.setAttribute('aria-hidden','false');open.setAttribute('aria-expanded','true')});
 closeEls.forEach(el=>el.addEventListener('click',close));
 document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
 document.querySelectorAll('[data-year]').forEach(e=>e.textContent=new Date().getFullYear());
});